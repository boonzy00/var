| Command | Mean [ms] | Min [ms] | Max [ms] | Relative |
|:---|---:|---:|---:|---:|
| `./zig-out/bin/var_benchmark` | 0.2 ± 0.1 | 0.1 | 0.4 | 1.00 |
