| Command | Mean [s] | Min [s] | Max [s] | Relative |
|:---|---:|---:|---:|---:|
| `./zig-out/bin/var_benchmark` | 4.296 ± 0.027 | 4.256 | 4.328 | 1.00 |
